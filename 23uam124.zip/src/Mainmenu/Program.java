package Mainmenu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

import entity.Album;
import entity.Artist;
import entity.Track;
import dbutil.Dbutil;

public class Program {

	//case 1
	public static void addArtist(Scanner sc) {
		Artist artist=new Artist();
		artist.accept(sc);
		String sql="INSERT INTO artist(artist_id,name) VALUES(?,?)";
		try(Connection connection=Dbutil.getConnection()){
			try(PreparedStatement insertStatement=connection.prepareStatement(sql)){
				insertStatement.setInt(1, artist.getArtist_id());
				insertStatement.setString(2, artist.getName());
				insertStatement.executeUpdate();
				System.out.println("Artist added successfully :)"+artist);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
//case 2
		public static void addAlbum(Scanner sc) {
			Album album=new Album();
			album.accept(sc);
			String sql="INSERT INTO album(album_id,title) VALUES(?,?)";
			try(Connection connection=Dbutil.getConnection()){
				try(PreparedStatement insertStatement=connection.prepareStatement(sql)){
					insertStatement.setInt(1, album.getAlbum_id());
					insertStatement.setString(2, album.getTitle());
					insertStatement.executeUpdate();
					System.out.println("Album added successfully :)"+album);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	// case 3
		public static void addTrack(Scanner sc) {
			Track track = new Track();
			track.accept(sc);
			
		    System.out.print("Enter Track ID: ");
		    int trackId = sc.nextInt();
		    sc.nextLine(); // consume newline

		    System.out.print("Enter Track Title: ");
		    String title = sc.nextLine();

		    System.out.print("Enter Album ID: ");
		    int albumId = sc.nextInt();

		    System.out.print("Enter Artist ID: ");
		    int artistId = sc.nextInt();

		    String sql = "INSERT INTO track(track_id, title, album_id, artist_id) VALUES (?, ?, ?, ?)";

		    try (Connection connection = Dbutil.getConnection()){
		        try( PreparedStatement stmt = connection.prepareStatement(sql)) {
		        stmt.setInt(1, trackId);
		        stmt.setString(2, title);
		        stmt.setInt(3, albumId);
		        stmt.setInt(4, artistId);
		        stmt.executeUpdate();
		        System.out.println("Track added successfully!");
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

//case 4
		public static void displayArtists() {
			String sql = "SELECT * FROM artist";
			try (Connection connection = Dbutil.getConnection()) {
				try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
					ResultSet rs = selectStatement.executeQuery();
					List<Artist> artistList = new ArrayList<>();
					while (rs.next()) {
						Artist artist = new Artist();
						artist.setArtist_id(rs.getInt(1));
						artist.setName(rs.getString(2));
						artistList.add(artist);
					}
					artistList.forEach(a -> System.out.println(a));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
//case 5
				public static void displayAlbums() {
					String sql = "SELECT * FROM album";
					try (Connection connection = Dbutil.getConnection()) {
						try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
							ResultSet rs = selectStatement.executeQuery();
							List<Album> albumList = new ArrayList<>();
							while (rs.next()) {
								Album album = new Album();
								album.setAlbum_id(rs.getInt(1));
								album.setTitle(rs.getString(2));
								albumList.add(album);
							}
							albumList.forEach(a -> System.out.println(a));
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
// case 6
				public static void viewTracksByArtist(Scanner sc) {
				    System.out.print("Enter Artist ID: ");
				    int artistId = sc.nextInt();

				    String sql = "SELECT track_id, title FROM track WHERE artist_id = ?";

				    try (Connection connection = Dbutil.getConnection();
				         PreparedStatement stmt = connection.prepareStatement(sql)) {
				        stmt.setInt(1, artistId);
				        ResultSet rs = stmt.executeQuery();
				        while (rs.next()) {
				            System.out.println("Track ID: " + rs.getInt("track_id") + ", Title: " + rs.getString("title"));
				        }
				    } catch (SQLException e) {
				        e.printStackTrace();
				    }
				}

	// case 7
				public static void displayTracks() {
				    String sql = "SELECT * FROM track";
				    try (Connection connection = Dbutil.getConnection();
				         PreparedStatement stmt = connection.prepareStatement(sql);
				         ResultSet rs = stmt.executeQuery()) {

				        while (rs.next()) {
				            System.out.println("Track ID: " + rs.getInt("track_id")
				                + ", Title: " + rs.getString("title")
				                + ", Album ID: " + rs.getInt("album_id")
				                + ", Artist ID: " + rs.getInt("artist_id"));
				        }

				    } catch (SQLException e) {
				        e.printStackTrace();
				    }
				}
// case 8
				public static void viewTracksByAlbum(Scanner sc) {
				    System.out.print("Enter Album ID: ");
				    int albumId = sc.nextInt();

				    String sql = "SELECT track_id, title FROM track WHERE album_id = ?";

				    try (Connection connection = Dbutil.getConnection();
				         PreparedStatement stmt = connection.prepareStatement(sql)) {
				        stmt.setInt(1, albumId);
				        ResultSet rs = stmt.executeQuery();
				        while (rs.next()) {
				            System.out.println("Track ID: " + rs.getInt("track_id") + ", Title: " + rs.getString("title"));
				        }
				    } catch (SQLException e) {
				        e.printStackTrace();
				    }
				}

		
	public static int menu( Scanner sc) {
		System.out.println("**************************");
		System.out.println("0.Exit");
		System.out.println("1. Add a new artist");
		System.out.println("2. Add a new album ");
		System.out.println("3. Artist adds a track for the album");
		System.out.println("4. Display all artists");
		System.out.println("5. Display all albums ");
		System.out.println("6. View all tracks for a given artist");
		System.out.println("7. Display all tracks ");
		System.out.println("8. View all tracks for a given album");
		System.out.println("**************************");
		System.out.print("Enter your choice:");
		int choice=sc.nextInt();
		return choice;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int choice;
		//Artist artist=null;
		
		while((choice = menu(sc))!=0) {
			switch(choice) {
				case 1:
					addArtist(sc);
					break;
				case 2:
					addAlbum(sc);
					break;
				case 3:
					 addTrack(sc);
					break;
				case 4:
					displayArtists();
					break;
				case 5:
					 displayAlbums();
					break;
				case 6:
					viewTracksByArtist(sc);
					break;
				case 7:
					displayTracks();
					break;
				case 8:
					viewTracksByAlbum(sc);
					break;
				default:
					System.out.println("Wrong choice!!!");
					break;
			
			}
		}
		sc.close();
		System.out.println("Thank you ,for visiting our application :)");
	}

}

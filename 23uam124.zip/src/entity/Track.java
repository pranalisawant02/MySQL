package entity;

import java.util.Scanner;

public class Track {
    private int track_id;
    private String title;
    private int album_id;
    private int artist_id;

    // Accept data from user
    public void accept(Scanner sc) {
        System.out.print("Enter Track ID: ");
        track_id = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter Track Title: ");
        title = sc.nextLine();

        System.out.print("Enter Album ID: ");
        album_id = sc.nextInt();

        System.out.print("Enter Artist ID: ");
        artist_id = sc.nextInt();
    }

    // Getters and Setters
    public int getTrack_id() {
        return track_id;
    }

    public void setTrack_id(int track_id) {
        this.track_id = track_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getAlbum_id() {
        return album_id;
    }

    public void setAlbum_id(int album_id) {
        this.album_id = album_id;
    }

    public int getArtist_id() {
        return artist_id;
    }

    public void setArtist_id(int artist_id) {
        this.artist_id = artist_id;
    }

    // toString() for display
    @Override
    public String toString() {
        return "Track ID: " + track_id +
               ", Title: " + title +
               ", Album ID: " + album_id +
               ", Artist ID: " + artist_id;
    }
}
